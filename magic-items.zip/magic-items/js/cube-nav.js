(() => {
  const cube = document.getElementById('cube');
  if (!cube) return; // this script only runs on the index page

  const FACE_NAMES = [
    'The Foreseeing Camera',
    'The Verbatim Keyboard',
    'The Recollection Chair',
    'The Longing Jacket',
    'The Foretelling Wallet',
    'The Manifest Book'
  ];

  const STOPS = [
    { ry: 0 },
    { ry: -60 },
    { ry: -120 },
    { ry: -180 },
    { ry: -240 },
    { ry: -300 }
  ];
  const N = STOPS.length;

  const dom = {
    cube,
    countEl: document.getElementById('cube_count'),
    progFill: document.getElementById('cube_prog_fill'),
    sceneName: document.getElementById('cube_scene_name'),
    dots: [...document.querySelectorAll('.cube-dot')],
    steps: [...document.querySelectorAll('.cube-step')]
  };

  let stepTops = [];
  const buildStepTops = () => {
    stepTops = dom.steps.map(s => s.getBoundingClientRect().top + window.scrollY);
  };
  buildStepTops();

  window.addEventListener('resize', buildStepTops);
  let resizePending = false;
  const ro = new ResizeObserver(() => {
    if (resizePending) return;
    resizePending = true;
    requestAnimationFrame(() => {
      buildStepTops();
      resizePending = false;
    });
  });
  ro.observe(document.documentElement);

  const easeIO = (t) => (t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t);

  // Continuous 0..1 phase across the cube's own scroll region only —
  // independent of how tall the header/footer around it are.
  const phaseFromScroll = (y) => {
    if (stepTops.length < 2) return 0;
    const first = stepTops[0];
    const last = stepTops[stepTops.length - 1];
    if (last <= first) return 0;
    return Math.max(0, Math.min(1, (y - first) / (last - first)));
  };

  const indexFromScroll = (y) => {
    const mid = y + innerHeight * 0.5;
    let idx = 0;
    for (let i = 0; i < stepTops.length; i++) {
      if (mid >= stepTops[i]) idx = i;
    }
    return Math.min(idx, N - 1);
  };

  const setCubeTransform = (phase) => {
    const t = phase * (N - 1);
    const i = Math.min(Math.floor(t), N - 2);
    const f = easeIO(t - i);
    const a = STOPS[i];
    const b = STOPS[i + 1];
    const ry = a.ry + (b.ry - a.ry) * f;
    dom.cube.style.transform = `rotateY(${ry}deg)`;
  };

  let lastIdx = -1;
  const updateHUD = (phase, idx) => {
    dom.progFill.style.width = `${Math.round(phase * 100)}%`;
    if (idx !== lastIdx) {
      lastIdx = idx;
      dom.countEl.textContent = `${String(idx + 1).padStart(2, '0')} / ${String(N).padStart(2, '0')}`;
      dom.sceneName.textContent = FACE_NAMES[idx] ?? '';
      dom.dots.forEach((d, i) => d.classList.toggle('active', i === idx));
    }
  };

  let smoothPhase = 0;
  let lastNow = performance.now();

  const frame = (now) => {
    requestAnimationFrame(frame);
    if (document.hidden) { lastNow = now; return; }
    const dt = Math.min((now - lastNow) / 1000, 0.05);
    lastNow = now;

    const targetPhase = phaseFromScroll(window.scrollY);
    smoothPhase += (targetPhase - smoothPhase) * (1 - Math.exp(-dt * 9));
    if (Math.abs(targetPhase - smoothPhase) < 0.0005) smoothPhase = targetPhase;

    setCubeTransform(smoothPhase);
    updateHUD(targetPhase, indexFromScroll(window.scrollY));
  };
  requestAnimationFrame(frame);

  // Dot navigation: smooth-scroll to the step for the clicked face.
  const easeInOutCubic = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href^="#c"]');
    if (!a) return;
    const target = document.querySelector(a.getAttribute('href'));
    if (!target || !target.classList.contains('cube-step')) return;
    e.preventDefault();
    const idx = dom.steps.indexOf(target);
    const targetY = idx >= 0 ? stepTops[idx] : target.getBoundingClientRect().top + window.scrollY;

    const startY = window.scrollY;
    const diff = targetY - startY;
    const duration = 650;
    const start = performance.now();
    const tick = (now) => {
      const p = Math.min(1, (now - start) / duration);
      window.scrollTo(0, startY + diff * easeInOutCubic(p));
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });
})();
