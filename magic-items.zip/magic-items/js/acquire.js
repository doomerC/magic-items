// Acquisition panel — visual payment-method selector only.
// No form submission, no network request: this is a front-end mockup.
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.pay-methods').forEach(group => {
    group.addEventListener('click', (e) => {
      const btn = e.target.closest('.pay-btn');
      if (!btn) return;
      group.querySelectorAll('.pay-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  document.querySelectorAll('.acquire-cta').forEach(cta => {
    cta.addEventListener('click', () => {
      cta.textContent = 'Request Filed ✓';
      cta.disabled = true;
      setTimeout(() => {
        cta.textContent = cta.dataset.originalLabel || 'Petition for Custody →';
        cta.disabled = false;
      }, 2200);
    });
    cta.dataset.originalLabel = cta.textContent;
  });
});
