// Watches the <model-viewer> on an item page. If the referenced .glb
// hasn't been dropped into /models yet (or fails to load), the rune
// frame shows a placeholder instead of a broken viewer.
document.addEventListener('DOMContentLoaded', () => {
  const mv = document.querySelector('model-viewer');
  const fallback = document.querySelector('.viewer-fallback');
  if (!mv || !fallback) return;

  const showFallback = () => { fallback.style.display = 'flex'; mv.style.opacity = '0'; };
  const hideFallback = () => { fallback.style.display = 'none'; mv.style.opacity = '1'; };

  showFallback(); // assume not-yet-present until proven otherwise

  mv.addEventListener('load', hideFallback);
  mv.addEventListener('error', showFallback);

  // model-viewer sometimes fails silently on a 404 without firing 'error'
  // in older browsers — double check the source actually resolves.
  fetch(mv.getAttribute('src'), { method: 'HEAD' })
    .then(res => { if (!res.ok) showFallback(); })
    .catch(() => showFallback());
});
